from asyncio import events
import pygame
import sys
pygame.init()

WHITE=pygame.Color (255,255,255)
YELLOW=pygame.Color(222,22,146)
GREEN=pygame.Color(255,0,110)
RED=pygame.Color(255,0,1)
BLACK = pygame.Color(0,0,0)
FPS=60

screen=pygame.display.set_mode([800,500])
pygame.display.set_caption("PRACTICA")
clock=pygame.time.Clock()

background=pygame.image.load("imagenes/6.jpg")
background=pygame.transform.scale(background,[800,500]).convert()
x = 0
y = 0
#VARIABLES
cord_x=400
cord_y=200

speed_x=3
speed_y=3

rect_x=10
rect_y=400

font=pygame.font.Font(None,30)
score=0

colisiones=False

while True:
    screen.blit(background,[0,0])
    circulo= pygame.draw.circle(screen,BLACK,[cord_x,cord_y],30)
    rectangulo=pygame.draw.rect (screen,WHITE,[rect_x,rect_y,300,10],0)

    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            sys.exit()
    posicion_relativa = x % background.get_rect().width

    screen.blit(background, (posicion_relativa - background.get_rect().width,y))
    if posicion_relativa < 800:
        screen.blit(background, (posicion_relativa,0))
        x-=5
        clock.tick(FPS)
    pygame.display.update()

 # MOVIMIENTOS  de la   esfera
    if (cord_x >= 775 or cord_x < 30):
        speed_x *= -1

    if (cord_y >= 470 or cord_y < 30):
        speed_y *= -1

    cord_x+=speed_x
    cord_y+=speed_y

# MANEJO DE EVENTOS

    if event.type==pygame.KEYDOWN:
        if event.key == pygame.K_RIGHT and rect_x < 600:
            rect_x += 8
        if event.key == pygame.K_LEFT:
            rect_x -= 8
        
        if event.key == pygame.K_UP:
            rect_y -= 8
        if event.key == pygame.K_DOWN:
            rect_y += 8
        
#COLISIONES
    score_text = font.render("score:" + str(score),True,BLACK)
    screen.blit(score_text,(10,10))

    if circulo.colliderect(rectangulo) and not colisiones:
        if speed_y > 0:
            speed_y = -speed_y
            cord_y -= 5
        elif speed_y < 0:
            speed_y = -speed_y
            cord_y += 5 
        score +=1
        colisiones=True
    else:
        colisiones=False


    pygame.display.flip()
    clock.tick(FPS)

