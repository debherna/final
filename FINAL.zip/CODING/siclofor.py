# estudiantes=["Mr. Elias","Hye Sung","Marlon","Judah","Maria"]
# for i in estudiantes:
#     print(i)
# print("\n")

# numeros=["1","2","3","4","5","6","7","8","9","10"]
# for i in numeros:
#     print(i)
# print("\n")


# for numeros in range(1,11):
#     print(numeros)
# print("\n")

# for numeros in range(1,12345556666666666677777888888888888889):
#     print(numeros*2)
# print("\n")

# cadena = "Hay una rana amarilla"
# letra = "a"
# contador = 0
# for letras in cadena:
#     if letras == letra:
#         contador += 1
#         print("la letra'{}'aparece {} veces.".format(letra,contador))
# print ("\n")
 
# for z in [1,2,3,4]:
#     print(z, end=",")
#     print("\n")0

# n = int(input("Ingresa un numero entero positivo N:"))
# suma=0
# for i in range(1, n+1):
#     numero_par=2*i
#     suma+=numero_par
#     print("La suma de los primeros {} numeros pares es: {}".format(n,suma))

# n = int(input("Ingresa un numero entero positivo que quieras multiplicar N:"))
# numero=0
# for i in range(n*1-10):
#      a=i*range
#      numero+=a
#      print("La suma de los primeros {} numeros pares es: {}".format(n,numero))

# for numeros in range(50,100):
#     if numeros%2==0:
#        print(numeros)

# for i in range(3,16):
#     if i % 2==0:
#         print (i,end="")
#         print("\n")

# n=5
# for i in range(n):
#      for j in range(n-i-1):
#           print(" ",end="")
#      for k in range(2*i+1):
#          print("*",end="")
#      print("")

# for i in [0,1,2]:
#     for j in [0,1]:
#         for x in [2,3]:
#             print(f"{i},{j},{x}")

# n=5
# for i in range(n):
#  for j in range(n-i-1):
#            print(" ",end="")
#       for k in range(2*i+1):
#           print("*",end="")
#       print("")    
# n=14
# for i in range(n):
#       for j in range(n-i-1):
#            print(" ",end="")
#       for k in range(2*i+1):
#           print("*",end="")
#       print("")
# d=11
# for i in range(d):
#      for j in range(d):
#           print(" ",end="")
#      for k in range(5):
#          print("*",end="")
#      print("")

# n=7
# for i in range(n):
#       for j in range(n-i-1):
#            print(" ",end="")
#       for k in range(2*i+1):
#           print("*",end="")
#       print("")
# d=4
# for i in range(d):
#      for j in range(d):
#           print(" ",end="")
#      for k in range(5):
#          print("*",end="")
#      print("")

# num = 10
# for i in range(num):
#     print(f''*(num- i-1)+"*"*(2*i+1))
# for n in range(int(num/2)):
#     print(''*int(num-num/4))

# import random

# numero_secreto=random.randint(1, 100)
# print("Hola! Bienvenido a adivina el numero.")
# Adivinanza=input("Pienso en un numero entre 1 y 100, Adivina!")

# Intentos_maximos=10
# for intento in range(1,Intentos_maximos + 1):
#     guess=int(input(f"Intento{intento}/{Intentos_maximos}:Ingresa tu adivinanza"))

#     if guess < numero_secreto:
#         print ("El numero es mas grande.")
#     elif guess >numero_secreto:
#         print ("El numero es mas pequeno.")
#     else:
#         print (f"Felicidades Adivinatse el numero en {intento} Intentos!")
#         break
# else:
#     print(f"Agotaste tus {Intentos_maximos} intentos! El numero era {numero_secreto} Mejor suerte a la proxima")

# import random

# numero_secreto=random.randint(1, 10)
# print("Hola! Bienvenido a adivina el numero.")
# Adivinanza=input("Pienso en un numero entre 1 y 10, Adivina! Cual es tu nombre?")

# Intentos_maximos=10
# for intento in range(1,Intentos_maximos + 1):
#     guess=int(input(f"Intento{intento}/{Intentos_maximos}:Ingresa tu adivinanza"))

#     if guess < numero_secreto:
#         print ("El numero es mas grande.")
#     elif guess >numero_secreto:
#         print ("El numero es mas pequeno.")
#     else:
#         print (f"Felicidades {Adivinanza} Adivinatse el numero en {intento} Intentos!")
#         break
# else:
#     print(f"OH NO {Adivinanza}, Agotaste tus {Intentos_maximos} intentos! El numero era {numero_secreto} Mejor suerte a la proxima")


# import random 
# num = random. randint(1, 10) 
# guess = None 
# while guess != num: 
#     guess = input("guess a number between 1 and 10: ") 
#     guess = int(guess) 

# if guess == num:
#     print("congratulation")
# else:
#  print("nope, sorry. try again!")


# import random
# print("Piensa en un numero en tu cabeza ")
# num = random. randint(1, 10) 
# print(num)
# pregunta= input("Ese era tu numero?")
# while pregunta=="correcto":
#   print("QUE BIEN, pude adivinar tu numero")
# if pregunta =="mayor":
#  num = random. randint(1, 10) 
# elif pregunta =="menor":
#  num = random. randint(1, 10) 

# import random
# print("Piensa en un numero en tu cabeza ")
# num = random. randint(1, 10) 
# print(num)
# pregunta= input("Ese era tu numero?")
# if pregunta=="correcto":
#   print("QUE BIEN, pude adivinar tu numero")

