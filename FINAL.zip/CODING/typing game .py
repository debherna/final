import pygame
import sys
import random
import time
import os

current_wd = os.getcwd()
folder = 'imagenes'
os.chdir(os.path.join(current_wd, folder))

pygame.init()

# pantalla
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Emoji Typing Game for Kids")

# Load the background image
background_image = pygame.image.load("zoo.jpg")
background_image = pygame.transform.scale(background_image, (screen_width, screen_height))

# Colores
white = (255, 255, 255)
black = (0, 0, 0)
red = (255, 0, 0)

# Emoji images for letters (scaled to 50x50 pixels)
emoji_size = (50, 50)
imagenes = {
    'K': pygame.transform.scale(pygame.image.load("koala.png"), emoji_size),
    'P': pygame.transform.scale(pygame.image.load("perro.png"), emoji_size),
    'O': pygame.transform.scale(pygame.image.load("oso.png"), emoji_size),
    'C': pygame.transform.scale(pygame.image.load("cerdo.jpg"), emoji_size),
    'T': pygame.transform.scale(pygame.image.load("tortuga.png"), emoji_size),
    'D': pygame.transform.scale(pygame.image.load("delfin.png"), emoji_size),
    'J': pygame.transform.scale(pygame.image.load("jirafa.png"), emoji_size),
    'G': pygame.transform.scale(pygame.image.load("gato.png"), emoji_size),
    'A': pygame.transform.scale(pygame.image.load("abeja.png"), emoji_size),
}

# Variables del juego
letras = random.choice("KPOCTDJGA")
letter_x = random.randint(150, 650)  # Restrict x position within the rectangle
letter_y = 100
speed = 3
score = 0
font = pygame.font.Font(None, 36)
start_time = None
words_typed = 0
game_over = False

# Define different levels with increasing speed
levels = [
    {"emojis": "KPOCTDJGA", "speed": 3, "emojis_required": 20},
    {"emojis": "KPOCTDJGA", "speed": 4, "emojis_required": 30},
    {"emojis": "KPOCTDJGA", "speed": 5, "emojis_required": 40},
]

current_level = 0  # Start with the first level

# Bucle principal del juego
running = True
clock = pygame.time.Clock()

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()

    # Dibujar la pantalla with the same background image
    screen.blit(background_image, (0, 0))

    # Dibujar el emoji
    emoji_image = imagenes.get(letras, None)
    if emoji_image:
        screen.blit(emoji_image, (letter_x, letter_y))

    # Mover el emoji hacia abajo
    letter_y += levels[current_level]["speed"]
    if not game_over:
        # Verificar si se presiona la tecla correcta
        for letter in levels[current_level]["emojis"]:
            if keys[pygame.key.key_code(letter)] and letras == letter:
                score += 1
                letras = random.choice(levels[current_level]["emojis"])
                letter_x = random.randint(150, 650)  # Restrict x position within the rectangle
                letter_y = 100

                # Comenzar a contar el tiempo cuando se presiona la primera tecla
                if start_time is None:
                    start_time = time.time()

                # Contar las palabras tecleadas
                words_typed += 1

        # Si se han presionado suficientes teclas, pasa al siguiente nivel
        if words_typed >= levels[current_level]["emojis_required"]:
            end_time = time.time()
            total_time = end_time - start_time
            words_per_minute = int((words_typed / total_time) * 60)
            game_over = True
            current_level += 1

    if game_over:
        # Mostrar ventana emergente con el resultado
        pygame.draw.rect(screen, red, (150, 200, 500, 200))
        result_text = font.render("Juego terminado", True, white)
        screen.blit(result_text, (250, 250))
        result_text = font.render(f"Tiempo total: {total_time:.2f} segundos", True, white)
        screen.blit(result_text, (250, 300))
        result_text = font.render(f"PPM: {words_per_minute}", True, white)
        screen.blit(result_text, (250, 350))

        # Reset variables for the next level
        if current_level < len(levels):
            score = 0
            words_typed = 0
            game_over = False
            start_time = None

    # Dibujar la puntuación
    score_text = font.render(f"Puntuación: {score}", True, black)
    screen.blit(score_text, (10, 10))

    pygame.display.update()
    clock.tick(30)

# Salir del juego
pygame.quit()
sys.exit()
