import pygame
import sys
pygame.init()


WHITE = pygame.Color(222,222,146)
GREEN= pygame.Color(45,20,10)
YELLOW=pygame.Color(255,255,255)

screen=pygame.display.set_mode([800,500])

clock=pygame
cord_x=400
cord_y=200

speed_x=3
speed_y=3

while True:
    screen.fill(YELLOW)
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            sys.exit()

    pygame.display.flip()



while True:
    screen.fill(YELLOW)
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            sys.exit
    
    pygame.draw.circle(screen,GREEN,[cord_x,cord_y],30)

            

