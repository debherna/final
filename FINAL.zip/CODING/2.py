import pygame
import sys
import random
import time
import os

current_wd = os.getcwd()
folder = 'imagenes'
os.chdir(os.path.join(current_wd, folder))

pygame.init()
pygame.mixer.music.load("bell.mp3")
pygame.mixer.music.play()

# pantalla
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Emoji Typing Game for Kids")

background_image = pygame.image.load("zoo.jpg")
background_image = pygame.transform.scale(background_image, (screen_width, screen_height))

# Colores
white = (255, 255, 255)
black = (0, 0, 0)
red = (255, 0, 0)

# Emoji images for letters (scaled to 50x50 pixels)
emoji_size = (50, 50)
imagenes = {
    'K': pygame.transform.scale(pygame.image.load("koala.png"), emoji_size),
    'P': pygame.transform.scale(pygame.image.load("perro.png"), emoji_size),
    'O': pygame.transform.scale(pygame.image.load("oso.png"), emoji_size),
    'C': pygame.transform.scale(pygame.image.load("cerdo.jpg"), emoji_size),
    'T': pygame.transform.scale(pygame.image.load("tortuga.png"), emoji_size),
    'D': pygame.transform.scale(pygame.image.load("delfin.png"), emoji_size),
    'J': pygame.transform.scale(pygame.image.load("jirafa.png"), emoji_size),
    'G': pygame.transform.scale(pygame.image.load("gato.png"), emoji_size),
    'A': pygame.transform.scale(pygame.image.load("abeja.png"), emoji_size),
    'H': pygame.transform.scale(pygame.image.load("hippo.png"), emoji_size),
    'B': pygame.transform.scale(pygame.image.load("burro.png"), emoji_size),
    'I': pygame.transform.scale(pygame.image.load("iguana.png"), emoji_size),
    'Z': pygame.transform.scale(pygame.image.load("zorro.png"), emoji_size),
    'M': pygame.transform.scale(pygame.image.load("mono.png"), emoji_size),
    'S': pygame.transform.scale(pygame.image.load("snake.png"), emoji_size),
    'V': pygame.transform.scale(pygame.image.load("vaca.png"), emoji_size),
}

# Variables del juego
letras = random.choice("KPOCTDJGA")
letter_x = random.randint(150, 650)  # Restrict x position within the rectangle
letter_y = 100
speed = 3
level = 1  # Initialize level
levels = 10  # Total number of levels
score = 0
font = pygame.font.Font(None, 36)
start_time = None
words_typed = 0
game_over = False

# Bucle principal del juego
running = True
clock = pygame.time.Clock()

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()

    # Debug: Print the current letter being typed
    print(f"Current Letter: {letras}")

    # Dibujar la pantalla
    screen.blit(background_image, (0, 0))

    # Debug: Print the x and y position of the letter
    print(f"Letter Position (x, y): ({letter_x}, {letter_y})")

    # Rest of your code...

    pygame.display.update()
    clock.tick(30)

# Salir del juego
pygame.quit()
sys.exit()
