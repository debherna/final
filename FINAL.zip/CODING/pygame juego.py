import pygame
import sys
pygame.init()

WHITE= pygame.Color(255,255,255)
YELLOW=pygame.Color(222,222,146)
GREEN= pygame.Color(255,0,0)
RED = pygame.Color(255,0,0)
FPS=60

screen=pygame.display.set_mode([800,500])
pygame.display.set_caption("PRACTICA")
clock=pygame.time.Clock()

background=pygame.image.load("imagenes/3.jpg")
background=pygame.transform.scale(background,[800,500]).convert()
# VARIABLES
#==============================================================================
cord_x=400
cord_y=200

speed_x=3
speed_y=3

circle_x=10
circle_y=400

font= pygame.font.Font(None,30)
score=0

colisiones = False


#==============================================================================
while True:
    # cical=pygame.draw.circle(screen,RED,[30,50],30)
    # screen.fill(YELLOW)
    # for event in pygame.event.get():
    #     if event.type==pygame.QUIT:
    #         sys.exit()
    screen.blit(background,[0,0]) 
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            sys.exit()

# MOVIMIENTOS
# El  circulo y su movimiento
    # circulo = pygame.draw.circle(screen,WHITE,[cord_x,cord_y],30)  
    # if (cord_x >= 775 or cord_x  <30):
    #     speed_x *= -1
    # #     circulo = pygame.draw.circle(screen,RED,[cord_x,cord_y],30)
    
    # if (cord_y >= 470 or cord_y  <30):
    #     speed_y *= -1
    #     circulo = pygame.draw.circle(screen,RED,[cord_x,cord_y],30)

    # cord_x += speed_x
    # cord_y += speed_y
    if (cord_x >= 30 or cord_x  <100):
        speed_x *= -1
    #     circulo = pygame.draw.circle(screen,RED,[cord_x,cord_y],30)
    
    if (cord_y >= 30 or cord_y  <170):
        speed_y *= 1
        circulo = pygame.draw.circle(screen,RED,[cord_x,cord_y],30)

    cord_x += speed_x

    if event.type==pygame.KEYDOWN:
        if event.key == pygame.K_RIGHT and circle_x < 60:
            circle_x += 1
        if event.key == pygame.K_LEFT:
            circle_x -= 1
       
    # circel = pygame.draw.circle(screen,RED,[circle_x,circle_y],40)
    # if event.type==pygame.KEYDOWN:
    #     if event.key == pygame.K_RIGHT and circle_x < 600:
    #         circle_x += 8
    #     if event.key == pygame.K_LEFT:
    #         circle_x -= 8
        
    #     if event.key == pygame.K_UP:
    #         circle_y -= 8
    #     if event.key == pygame.K_DOWN:
    #         circle_y += 8



#COLISIONES
    # score_text = font.render("score:" + str(score),True,(255,0,0))
    # screen.blit(score_text,(10,10))

    # if circulo.colliderect(circle) and not colisiones:
    #     if speed_y > 0:
    #         speed_y = -speed_y
    #         cord_y -= 5
    #     elif speed_y < 0:
    #         speed_y = -speed_y
    #         cord_y += 5 
    #     score +=1
    #     colisiones=True
    # else:
    #     colisiones=False




    pygame.display.flip()
    clock.tick(FPS)


