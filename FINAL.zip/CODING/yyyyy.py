import pygame
import sys

# Initialize Pygame
pygame.init()

# Constants
SCREEN_WIDTH, SCREEN_HEIGHT = 800, 600
CIRCLE_RADIUS = 30
CIRCLE_COLOR = (0, 0, 0)
CLICK_POSITION = (100, 300)  # Initial position for the circle
MOVE_SPEED = 5  # Speed at which the circle moves

# Create the screen
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Moving Circle with Mouse Button")

# Create a circle surface
circle_surface = pygame.Surface((CIRCLE_RADIUS * 2, CIRCLE_RADIUS * 2), pygame.SRCALPHA)
pygame.draw.circle(circle_surface, CIRCLE_COLOR, (CIRCLE_RADIUS, CIRCLE_RADIUS), CIRCLE_RADIUS)

# Circle position
circle_x, circle_y = CLICK_POSITION
moving_left = False  # Flag to check if left mouse button is held down

# Game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:  # Left mouse button
                moving_left = True
        elif event.type == pygame.MOUSEBUTTONUP:
            if event.button == 1:  # Left mouse button released
                moving_left = False

    if moving_left:
        circle_x -= MOVE_SPEED  # Move left while the left button is held
    else:
        circle_x += MOVE_SPEED  # Move right when not holding the left button

    screen.fill((255, 255, 255))  # Fill the screen with white
    screen.blit(circle_surface, (circle_x - CIRCLE_RADIUS, circle_y - CIRCLE_RADIUS))
    pygame.display.flip()

# Quit Pygame
pygame.quit()
sys.exit()