import pygame
import sys
import random
import time
pygame.init()


# pantalla
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Juego de Mecanografía para Niños")


# Colores
white = (255, 255, 255)
black = (0, 0, 0)
red = (255, 0, 0)
.


# Variables del juego
letras = random.choice("ASDFGHJKL;'")
letter_x = random.randint(100, 700)
letter_y = 100
speed = 3
score = 0
font = pygame.font.Font(None, 36)
start_time = None
words_typed = 0
game_over = False






# Bucle principal del juego
running = True
clock = pygame.time.Clock()


while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False


    keys = pygame.key.get_pressed()


    # Dibujar la pantalla
    screen.fill(white)


    # Dibujar la letra
    letter_text = font.render(letras, True, red)
    screen.blit(letter_text, (letter_x, letter_y))

    # Mover la letra hacia abajo
    letter_y += speed
    if not game_over:
        # Verificar si se presiona la tecla correcta
        if keys[pygame.key.key_code(letras)]:
            score += 1
            letras = random.choice("ASDFGHJKL;'")
            letter_x = random.randint(100, 700)
            letter_y = 100


            # Comenzar a contar el tiempo cuando se presiona la primera tecla
            if start_time is None:
                start_time = time.time()


            # Contar las palabras tecleadas
            words_typed += 1


     # Si se han presionado 5 teclas, muestra el resultado y termina el juego
        if words_typed >= 5:
            end_time = time.time()
            total_time = end_time - start_time
            words_per_minute = int((words_typed / total_time) * 60)
            game_over = True
















    if game_over:
        # Mostrar ventana emergente con el resultado
        pygame.draw.rect(screen, red, (150, 200, 500, 200))
        result_text = font.render("Juego terminado", True, white)
        screen.blit(result_text, (250, 250))
        result_text = font.render(f"Tiempo total: {total_time:.2f} segundos", True, white)
        screen.blit(result_text, (250, 300))
        result_text = font.render(f"PPM: {words_per_minute}", True, white)
        screen.blit(result_text, (250, 350))
        
        score_text = font.render(f"Puntuación: {score}", True, black)
        screen.blit(score_text, (10, 10))
        pygame.display.update()
        pygame.time.delay(7000)  # Mostrar la ventana emergente durante 7 segundos
        running = False


    # Dibujar la puntuación
    pygame.display.update()
    clock.tick(30)
# Salir del juego
pygame.quit()
sys.exit()
