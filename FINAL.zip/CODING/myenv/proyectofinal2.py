import tkinter as tk
from tkinter import ttk
import pygame
import random

# Initialize Pygame
pygame.init()

# Define colors
colors = {
    'red': (255, 0, 0),
    'blue': (0, 0, 255),
    'light green': (0, 255, 0),
    'yellow': (255, 255, 0),
    'pink': (235, 52, 140),
    'dark green': (1, 50, 32),
    'purple': (47, 8, 54),
    'beige': (217, 178, 163),
    'orange': (255, 72, 0),
    # Add more colors as needed
}

# Create a Tkinter window
root = tk.Tk()
root.title("Color Learning App")

# Set up Pygame display
pygame_screen = pygame.display.set_mode((200, 200))

# Function to display colored objects
def display_color(color):
    pygame_screen.fill(colors[color])
    pygame.display.flip()

# Function to check if the selected color is correct
def check_color(selected_color):
    if selected_color == current_color.get():
        status_label.config(text="Correct!", foreground="green")
    else:
        status_label.config(text="Wrong! Try again.", foreground="red")

# Function to change the color
def change_color():
    color = random.choice(list(colors.keys()))
    display_color(color)
    current_color.set(color)

# Create buttons for each color
for color_name in colors:
    color_button = ttk.Button(root, text=color_name.capitalize(),
                              command=lambda c=color_name: check_color(c))
    color_button.pack()

# Create a status label
status_label = ttk.Label(root, text="")
status_label.pack()

# Create a button to change the color
change_color_button = ttk.Button(root, text="Next Color->", command=change_color)
change_color_button.pack()

# Initialize the current color
current_color = tk.StringVar()
change_color()

root.mainloop()