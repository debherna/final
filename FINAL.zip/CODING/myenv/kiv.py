from kivy.app import App
from kivy.uix.label import Label

class MiVentana(App):
    def build(self):
        etiqueta = Label(text="Esta es mi ventana Kivy!")
        return etiqueta

if __name__ == '__main__':
    MiVentana().run()
