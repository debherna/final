from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button

class TicTacToeApp(App):
    def build(self):
        self.title = 'Tic-Tac-Toe'
        self.game_board = [['' for _ in range(3)] for _ in range(3)]
        self.current_player = 'X'

        layout = BoxLayout(orientation='vertical')
        self.buttons = [[None for _ in range(3)] for _ in range(3)]


        self.reset_button = Button(text='Restart')
        self.reset_button.bind(on_release=self.reset_game)
        layout.add_widget(self.reset_button)


    def on_button_click(self, row, col):
        if not self.game_board[row][col]:
            self.game_board[row][col] = self.current_player
            self.buttons[row][col].text = self.current_player
            if self.check_winner(row, col, self.current_player):
                self.show_winner_message(self.current_player)
            elif all(self.game_board[i][j] for i in range(3) for j in range(3)):
                self.show_winner_message('Draw')
            else:
                self.current_player = 'O' if self.current_player == 'X' else 'X'

    def check_winner(self, row, col, player):
        # Check for a win in rows, columns, and diagonals
        return all(self.game_board[row][i] == player for i in range(3)) or \
               all(self.game_board[i][col] == player for i in range(3)) or \
               all(self.game_board[i][i] == player for i in range(3)) or \
               all(self.game_board[i][2 - i] == player for i in range(3))

    def show_winner_message(self, winner):
        self.reset_button.text = f'Restart (Winner: {winner})'
        for row in range(3):
            for col in range(3):
                self.buttons[row][col].disabled = True

    def reset_game(self, instance):
        self.game_board = [['' for _ in range(3)] for _ in range(3)]
        for row in range(3):
            for col in range(3):
                self.buttons[row][col].text = ''
                self.buttons[row][col].disabled = False
        self.current_player = 'X'
        self.reset_button.text = 'Restart'

if __name__ == '__main__':
    TicTacToeApp().run()
