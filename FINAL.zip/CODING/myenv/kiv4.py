import kivy
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput

class MyWindow(App):

    def build(self):
        layout = BoxLayout(orientation='vertical')
        
        etiqueta = Label(text='Soy una etiqueta secundaria.')
        etiqueta.font_name = 'rasberryjam-font'  # Set the font to 'Bubble font'
        layout.add_widget(etiqueta)

        text = TextInput()
        layout.add_widget(text)

        boton = Button(text='BOTON-1')
        boton.background_color = (0.1, 0.1, 0.5, 1)
        layout.add_widget(boton)
        return layout
    
    def presionar(self, instance):
        print("Botón presionado")

if __name__ == '__main__':
    MyWindow().run()
