from kivy.app import App
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label

class MyKivyApp(App) :
    def build(self):
        layout=BoxLayout(orientation='vertical', padding=10)
        self.button = Button(text= 'Haz clic en mi')
        self.button.bind(on_press=self.on_button_click)
        layout.add_widget (self.button)
        return layout

def on_button_click(self, instance):
    if self,button.text=='Haz click en mi':
    self.button.text=="Haz click en mi"
    self.button.text="Hiciste click"
else:
self.button.text="haz click en mi"

if __name__=='__main__':
    MyWindow().run()
