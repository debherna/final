import kivy
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button

class TaskApp(App):
    def build(self):
        self.tasks = []  # List to store tasks

        layout = BoxLayout(orientation='vertical')

        # Add a title Label
        title_label = Label(text='To-Do List', font_size=36, size_hint_y=None, height=50)
        layout.add_widget(title_label)

        self.task_input = TextInput(hint_text='Add a task')
        add_button = Button(text='Add Task')
        add_button.bind(on_press=self.add_task)
        layout.add_widget(self.task_input)
        layout.add_widget(add_button)

        self.task_labels = BoxLayout(orientation='vertical')
        layout.add_widget(self.task_labels)

        return layout

    def add_task(self, instance):
        task_text = self.task_input.text.strip()
        if task_text:
            task_label = Label(text=task_text)
            edit_button = Button(text='Edit')
            delete_button = Button(text='Delete')
            edit_button.bind(on_press=lambda instance, task=task_label: self.edit_task(task, instance))
            delete_button.bind(on_press=lambda instance, task=task_label: self.delete_task(task, instance))
            task_layout = BoxLayout(orientation='horizontal', spacing=10, padding=5)
            task_layout.add_widget(task_label)
            task_layout.add_widget(edit_button)
            task_layout.add_widget(delete_button)
            task_layout.background_color = (1, 0.2, 0.5, 1)  
            self.task_labels.add_widget(task_layout)
            self.tasks.append({'label': task_label, 'text': task_text})

        self.task_input.text = ''

    def edit_task(self, task, instance):
        # Find the task label associated with the edit button
        for task_info in self.tasks:
            if task_info['label'] is task:
                task_info['label'].text = self.task_input.text.strip()
                break

    def delete_task(self, task, instance):
        # Find the task label associated with the delete button
        for task_info in self.tasks:
            if task_info['label'] is task:
                self.task_labels.remove_widget(task.parent)
                self.tasks.remove(task_info)
                break

if __name__ == '__main__':
    TaskApp().run()
