from kivy.app import App
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.label import Label

class CalculatorApp(App):
    def build(self):
        self.operator = None
        self.last_value = None
        self.result = Label(font_size=32, halign='right', valign='center', size_hint=(1, 0.4))
        layout = GridLayout(cols=4, spacing=3, size_hint=(1, 0.6))

        buttons = [
            '7', '8', '9', '/',
            '4', '5', '6', '*',
            '1', '2', '3', '-',
            'C', '0', '=', '+'
        ]

        for button in buttons:
            if button == '=':
                equals_button = Button(text=button)
                equals_button.bind(on_press=self.on_solution)
                layout.add_widget(equals_button)
            elif button == 'C':
                clear_button = Button(text=button)
                clear_button.bind(on_press=self.on_clear)
                layout.add_widget(clear_button)
            else:
                num_button = Button(text=button)
                num_button.bind(on_press=self.on_button_click)
                layout.add_widget(num_button)

        layout.add_widget(self.result)

        return layout

    def on_button_click(self, instance):
        current_text = self.result.text
        button_text = instance.text

        if current_text == "Error":
            self.result.text = ""
            return

        if button_text in "1234567890":
            new_text = current_text + button_text
            self.result.text = new_text
        else:
            if self.last_value is None:
                self.last_value = float(current_text)
                self.result.text = ""
            else:
                self.calculate_result()
            self.operator = button_text

    def calculate_result(self):
        try:
            current_text = self.result.text
            new_value = float(current_text)
            if self.operator == '+':
                self.result.text = str(self.last_value + new_value)
            if self.operator == '*':
                self.result.text = str(self.last_value * new_value)
            if self.operator == '/':
                self.result.text = str(self.last_value / new_value)
            elif self.operator == '-':
                self.result.text = str(self.last_value - new_value)
        except ValueError:
            self.result.text = "Error"

    def on_solution(self, instance):
        if self.operator:
            self.calculate_result()
        self.operator = None
        self.last_value = None

    def on_clear(self, instance):
        self.result.text = ""
        self.operator = None
        self.last_value = None

if __name__ == '__main__':
    app = CalculatorApp()
    app.run()
