import tkinter as tk
from tkinter import ttk
import random

# Create the main application window
root = tk.Tk()
root.title("Shape Recognition App")

# Update the list of shapes
shapes = ["circle", "square", "triangle", "pentagon", "star"]

# Function to generate a random shape
def generate_shape():
    return random.choice(shapes)

# Function to display a shape on the canvas
def display_shape(shape):
    canvas.delete("all")  # Clear previous shape
    if shape == "circle":
        canvas.create_oval(50, 50, 250, 250, outline="black", width=2)
    elif shape == "square":
        canvas.create_rectangle(50, 50, 250, 250, outline="black", width=2)
    elif shape == "triangle":
        canvas.create_polygon(50, 250, 250, 250, 150, 50, outline="black", width=2)
    elif shape == "pentagon":
        canvas.create_polygon(50, 250, 100, 150, 200, 150, 250, 250, 150, 300, outline="black", width=2)
    elif shape == "star":
        canvas.create_polygon(150, 50, 190, 150, 300, 150, 210, 190, 230, 300, 150, 240, 70, 300, 93, 190,4,150,105,150, outline="black", width=2)

        
    # Add more shapes here if needed

# Function to check if the selected shape is correct
def check_shape(selection):
    global score
    if selection == current_shape:
        result_label.config(text="Correct!")
        score += 1
        score_label.config(text=f"Score: {score}")
    else:
        result_label.config(text="Incorrect. Try again!")

# Function to handle the 'Next' button click
def next_shape():
    global current_shape
    current_shape = generate_shape()
    display_shape(current_shape)
    result_label.config(text="")  # Clear previous result

# Create the canvas to display shapes
canvas = tk.Canvas(root, width=300, height=300)
canvas.pack()

# Create buttons for shape options
circle_btn = ttk.Button(root, text="Circle", command=lambda: check_shape("circle"))
circle_btn.pack()

square_btn = ttk.Button(root, text="Square", command=lambda: check_shape("square"))
square_btn.pack()

triangle_btn = ttk.Button(root, text="Triangle", command=lambda: check_shape("triangle"))
triangle_btn.pack()

# Create buttons for new shape options
pentagon_btn = ttk.Button(root, text="Pentagon", command=lambda: check_shape("pentagon"))
pentagon_btn.pack()

star_btn = ttk.Button(root, text="Star", command=lambda: check_shape("star"))
star_btn.pack()

# Create a 'Next' button to display the next shape
next_btn = ttk.Button(root, text="Next", command=next_shape)
next_btn.pack()

# Label to display feedback
result_label = ttk.Label(root, text="")
result_label.pack()

# Score label
score = 0
score_label = ttk.Label(root, text=f"Score: {score}")
score_label.pack()

# Initialize the first shape
current_shape = generate_shape()
display_shape(current_shape)

root.mainloop()
