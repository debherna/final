import pygame
import sys
pygame.init()

WHITE= pygame.Color(255,255,255)
YELLOW=pygame.Color(222,222,146)
GREEN= pygame.Color(255,0,0)
RED = pygame.Color(255,0,0)
FPS=60

screen=pygame.display.set_mode([800,500])
pygame.display.set_caption("PRACTICA")
clock=pygame.time.Clock()

background=pygame.image.load("imagenes/download.jpg")
background=pygame.transform.scale(background,[800,500]).convert()
# VARIABLES
#==============================================================================
cord_x=400
cord_y=200

speed_x=3
speed_y=3

rect_x=10
rect_y=400

font= pygame.font.Font(None,30)
score=0

colisiones = False

#==============================================================================
while True:
    # screen.fill(YELLOW)
    # for event in pygame.event.get():
    #     if event.type==pygame.QUIT:
    #         sys.exit()
    screen.blit(background,[0,0]) 
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            sys.exit()

# MOVIMIENTOS
# El  circulo y su movimiento
    circulo = pygame.draw.circle(screen,RED,[cord_x,cord_y],30)  
    if (cord_x >= 775 or cord_x  <30):
        speed_x *= -1
        circulo = pygame.draw.circle(screen,RED,[cord_x,cord_y],30)
    
    if (cord_y >= 470 or cord_y  <30):
        speed_y *= -1
        circulo = pygame.draw.circle(screen,RED,[cord_x,cord_y],30)

    cord_x += speed_x
    cord_y += speed_y

# EVENTOS
    rectangulo = pygame.draw.rect(screen,RED,[rect_x,rect_y,300,10],0)
    if event.type==pygame.KEYDOWN:
        if event.key == pygame.K_RIGHT and rect_x < 600:
            rect_x += 8
        if event.key == pygame.K_LEFT:
            rect_x -= 8
        
        if event.key == pygame.K_UP:
            rect_y -= 8
        if event.key == pygame.K_DOWN:
            rect_y += 8



#COLISIONES
    score_text = font.render("score:" + str(score),True,(255,0,0))
    screen.blit(score_text,(10,10))

    if circulo.colliderect(rectangulo) and not colisiones:
        if speed_y > 0:
            speed_y = -speed_y
            cord_y -= 5
        elif speed_y < 0:
            speed_y = -speed_y
            cord_y += 5 
        score +=1
        colisiones=True
    else:
        colisiones=False




    pygame.display.flip()
    clock.tick(FPS)



