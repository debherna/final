import pygame
import sys
import os  # Import the os module for path manipulation

# Initialize Pygame
pygame.init()

# Constants
SCREEN_WIDTH, SCREEN_HEIGHT = 800, 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("imagenes")

# Load background image
background = pygame.image.load("imagenes/target2.jpg")
background = pygame.transform.scale(background, [800, 600]).convert()

# Emoji properties
EMOJI_WIDTH, EMOJI_HEIGHT = 80, 80

# Specify the directory path for emoji images
emoji_directory = "imagenes"  # Change this to the actual directory path if needed

# Load emoji images
SAD_EMOJI = pygame.image.load(os.path.join(emoji_directory, "sad.png"))
SAD_EMOJI = pygame.transform.scale(SAD_EMOJI, (EMOJI_WIDTH, EMOJI_HEIGHT))
HAPPY_EMOJI = pygame.image.load(os.path.join(emoji_directory, "happy.png"))
HAPPY_EMOJI = pygame.transform.scale(HAPPY_EMOJI, (EMOJI_WIDTH, EMOJI_HEIGHT))

# Flag to keep track of emoji state (happy or sad)
emoji_happy = False

CLICK_POSITION = (100, 250)
MOVE_SPEED = 1

# Create the screen
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Moving Emoji on Click")

# Emoji position
emoji_x, emoji_y = CLICK_POSITION
moving = False
direction = 2

# Score and speed variables
score = 0
speed = MOVE_SPEED
font = pygame.font.Font(None, 36)  # Font for displaying the score

# Game loop
running = True
while running:
    screen.blit(background, [0, 0])
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                if not moving:
                    moving = True
                else:
                    moving = False
                    emoji_happy = False  # Set emoji state to sad when clicked

                # Check if the emoji is stopped in the center
                if SCREEN_WIDTH / 2 - EMOJI_WIDTH / 2 <= emoji_x <= SCREEN_WIDTH / 2.4 + EMOJI_WIDTH / 2.4:
                    score += 1  
                    speed += 1  
                    emoji_happy = True 

    if moving:
        emoji_x += direction * speed

        if emoji_x + EMOJI_WIDTH >= SCREEN_WIDTH:
            direction = -1
        elif emoji_x <= 0:
            direction = 1

    # Display the emoji (sad or happy) based on the emoji_happy state
    if emoji_happy:
        screen.blit(HAPPY_EMOJI, (emoji_x, emoji_y))
    else:
        screen.blit(SAD_EMOJI, (emoji_x, emoji_y))

    # Display the score in red
    score_text = font.render(f"Score: {score}", True, (255, 0, 0))
    screen.blit(score_text, (10, 10))

    pygame.display.flip()

# Quit Pygame
pygame.quit()
sys.exit()
