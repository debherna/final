# edad=15
# if edad >=65:
#     print("estas en edad de jubilacion")
# else:
#     print("no estas en edad de jubilacion")

# edad=int(input("escribe tu edad")) 
# if edad >=65:
#     print("estas en edad de jubilacion")
# else:
#     print("no estas en edad de jubilacion")

# nombre=(input("Cual es tu nombre?"))
# materia=(input("Cual es tu materia favorita?"))
# if materia == ('matematicas'):


# while True:
    
#     if pregunta =="no":
#         color=input ("Ingresa tu color favorito")
#     pregunta=input("estas seguro que este es tu color favorito? (si o no)")
#     break

# nombre=input("Ingresa tu nombre")
# color=input ("Ingresa tu color favorito")
# pregunta=input("estas seguro que este es tu color favorito? (si o no)")

# if pregunta== "no":
#     color=input ("Ingresa tu color favorito")
# else:
#     print("tu color favorito es {color}")


# saldo= 2000 #saldo inicial
# retiro=float(input("Cuantos dolares deseas retirar:"))
# if retiro <=200:
#     comision=0
# else:
#     comision=2
#     saldo-= retiro+ comision
#     print(f"retiraste $[{retiro:.2f}. Comision:{comision:.2f}. Saldo restante $ {saldo:.2f}")
# else:
# print("saldo insuficiente")
 
# print("Hola Bienvenido a restaurante Debora! El Menu del Dia incluye:")
# print("1. Pasta \n2.pizza \n3.ensalada")
# comida=input("Elige 1 opcion porfavor:")
# if comida== "nada":
#     print("entonces para que vino? ")
# else:
#     print(f"Saborea una deliciosa, {comida}")

print("Hola Bienvenido a restaurante Debora! El Menu del Dia incluye:")
print("1.pasta \n2.pizza \n3.ensalada")
comida= int(input("Elige 1 opcion porfavor:"))
if comida==1:
    print("Saborea una deliciosa pasta") 
if comida==2:
     print("Saborea una deliciosa pizza")
if comida==3:
     print("Saborea una deliciosa ensalada")
while True:
    if duda =="no":
        duda=input("Quieres agrar otro articulo del menu? (si o no)")
 
        break
