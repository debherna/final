import pygame
import sys
import random
import time
import os

current_wd = os.getcwd()
folder = 'imagenes'
os.chdir(os.path.join(current_wd, folder))

pygame.init()

# pantalla
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Emoji Typing Game for Kids")

# Define background images for each level
background_images = [
    pygame.image.load("background1.jpg"),
    pygame.image.load("background2.jpg"),
    pygame.image.load("background3.jpg"),
    pygame.image.load("background4.jpg"),
    pygame.image.load("background5.jpg"),
]

# Colores
white = (255, 255, 255)
black = (0, 0, 0)
red = (255, 0, 0)

# Emoji images for letters (scaled to 50x50 pixels)
emoji_size = (50, 50)
imagenes = {
    'K': pygame.transform.scale(pygame.image.load("koala.png"), emoji_size),
    'P': pygame.transform.scale(pygame.image.load("perro.png"), emoji_size),
    'O': pygame.transform.scale(pygame.image.load("oso.png"), emoji_size),
    'C': pygame.transform.scale(pygame.image.load("cerdo.jpg"), emoji_size),
    'T': pygame.transform.scale(pygame.image.load("tortuga.png"), emoji_size),
    'D': pygame.transform.scale(pygame.image.load("delfin.png"), emoji_size),
    'J': pygame.transform.scale(pygame.image.load("jirafa.png"), emoji_size),
    'G': pygame.transform.scale(pygame.image.load("gato.png"), emoji_size),
    'A': pygame.transform.scale(pygame.image.load("abeja.png"), emoji_size),
    'H': pygame.transform.scale(pygame.image.load("hippo.png"), emoji_size),
    'B': pygame.transform.scale(pygame.image.load("burro.png"), emoji_size),
    'I': pygame.transform.scale(pygame.image.load("iguana.png"), emoji_size),
    'Z': pygame.transform.scale(pygame.image.load("zorro.png"), emoji_size),
    'M': pygame.transform.scale(pygame.image.load("mono.png"), emoji_size),
    'S': pygame.transform.scale(pygame.image.load("snake.png"), emoji_size),
    'V': pygame.transform.scale(pygame.image.load("vaca.png"), emoji_size),
}

# Create a font for displaying the level
level_font = pygame.font.Font(None, 36)

# Variables del juego
letras = random.choice("KPOCTDJGA")
letter_x = random.randint(150, 650)
letter_y = 100
score = 0
font = pygame.font.Font(None, 36)
start_time = None
words_typed = 0
game_over = False

# Define different levels with increasing speed, emojis, and backgrounds
levels = [
    {"emojis": "KPOCTDJGA", "speed": 3, "emojis_required": 12, "background": 0},
    {"emojis": "KPOCTDJGA", "speed": 4, "emojis_required": 12, "background": 1},
    {"emojis": "KPOCTDJGA", "speed": 5, "emojis_required": 12, "background": 2},
    {"emojis": "KPOCTDJGA", "speed": 6, "emojis_required": 12, "background": 3},
    {"emojis": "KPOCTDJGA", "speed": 7, "emojis_required": 12, "background": 4},
]

current_level = 0

# WPM display time in seconds
wpm_display_time = 3

# Bucle principal del juego
running = True
clock = pygame.time.Clock()

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()

    background_image = pygame.transform.scale(background_images[levels[current_level]["background"]], (screen_width, screen_height))
    screen.blit(background_image, (0, 0))

    level_text = level_font.render(f"Nivel {current_level + 1}", True, black)
    screen.blit(level_text, (10, 50))

    if not game_over:
        emoji_image = imagenes.get(letras, None)
        if emoji_image:
            screen.blit(emoji_image, (letter_x, letter_y))

        letter_y += levels[current_level]["speed"]

        for letter in levels[current_level]["emojis"]:
            if keys[ord(letter)] and letras == letter:
                score += 1
                letras = random.choice(levels[current_level]["emojis"])
                letter_x = random.randint(150, 650)
                letter_y = 100

                if start_time is None:
                    start_time = time.time()

                words_typed += 1

        if words_typed >= levels[current_level]["emojis_required"]:
            end_time = time.time()
            total_time = end_time - start_time
            words_per_minute = int((words_typed / total_time) * 60)
            game_over = True
            level_complete = True
            current_level += 1

    if game_over:
        if level_complete:
            if time.time() - end_time < wpm_display_time:
                result_text = font.render(f"PPM: {words_per_minute}", True, white)
                screen.blit(result_text, (250, 250))
            else:
                level_complete = False
                score = 0
                words_typed = 0
                game_over = False
                start_time = None
        else:
            pygame.draw.rect(screen, red, (150, 200, 500, 200))
            result_text = font.render("Juego terminado", True, white)
            screen.blit(result_text, (250, 250))
            result_text = font.render(f"Tiempo total: {total_time:.2f} segundos", True, white)
            screen.blit(result_text, (250, 300))

            if current_level < len(levels):
                score = 0
                words_typed = 0
                game_over = False
                start_time = None

    score_text = font.render(f"Puntuación: {score}", True, black)
    screen.blit(score_text, (10, 10))

    pygame.display.update()
    clock.tick(30)

# Salir del juego
pygame.quit()
sys.exit()
